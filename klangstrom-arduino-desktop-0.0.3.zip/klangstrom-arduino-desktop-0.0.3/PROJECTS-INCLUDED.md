# Klangstrom for Arduino / Projects Included

- [STM32duino](https://github.com/stm32duino)
- [SDL](https://www.libsdl.org)
- [SdFat](https://github.com/greiman/SdFat)
- [tiny file dialogs](http://tinyfiledialogs.sourceforge.net/)
- [TinyDir](https://github.com/cxong/tinydir)
- [TinyUSB](tinyusb.org)
- [Mutable Instruments](https://github.com/pichenettes/eurorack)
