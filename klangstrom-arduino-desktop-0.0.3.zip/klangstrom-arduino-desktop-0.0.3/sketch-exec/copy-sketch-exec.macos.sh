#!/bin/bash

/bin/cp $1 /tmp/
