#ifndef RENDER_H
#define RENDER_H

void Render(void);
void SetMouthThroat(unsigned char mouth, unsigned char throat);

#endif
