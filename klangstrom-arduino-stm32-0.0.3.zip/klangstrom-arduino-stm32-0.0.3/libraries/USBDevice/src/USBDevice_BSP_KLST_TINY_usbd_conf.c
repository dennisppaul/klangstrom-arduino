#include "USBDevice_BSP_inc.h"

#ifdef USE_USBDEVICE
#ifdef KLST_BOARD_KLST_TINY

#error "USB Device currently not implemented"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif // USE_USBDEVICE
#endif // KLST_BOARD_KLST_TINY
